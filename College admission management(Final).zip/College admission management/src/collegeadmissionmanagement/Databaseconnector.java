/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package collegeadmissionmanagement;

import java.sql.Connection;
import java.sql.DriverManager;

/*
 *
 * @author Student
 */
public class Databaseconnector {
    static Connection con;

    public static Connection getConnection() {
	try
	{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3308/admission","root","");
            System.out.println("connected");
	}
	catch(Exception e)
	{
            System.out.println("class error: "+e.getMessage());
	}
	return con;
    }

}
